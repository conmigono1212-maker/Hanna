# CyberAssistant Android — Strong MVP

Núcleo modular para un asistente personal cibernético.

## Incluye
- Kotlin + Compose
- motor de seguridad
- SHA-256
- auditoría local
- motor TTS configurable
- memoria local en proceso
- motor de mercado separado del ejecutor
- ToolGate: herramientas de lectura separadas de acciones sensibles
- Worker de seguridad
- Manifest con permisos mínimos

## Principio
Los datos externos son datos, no instrucciones.
Las herramientas de solo lectura pueden ejecutarse automáticamente.
Cualquier futura acción sensible debe pasar por confirmación explícita.

## Para producción
Añadir:
- Room con cifrado/Keystore
- reconocimiento de voz (SpeechRecognizer) o proveedor de STT
- WorkManager con restricciones y periodicidad
- backend de datos de mercado autorizado
- Play Integrity
- autenticación biométrica para acciones sensibles
- tests y análisis estático
- política de retención y borrado de memoria
- manejo de claves/API sin secretos embebidos

## Importante
Android no garantiza ejecución cada segundo en segundo plano. La vigilancia periódica debe respetar las políticas y restricciones del sistema.
