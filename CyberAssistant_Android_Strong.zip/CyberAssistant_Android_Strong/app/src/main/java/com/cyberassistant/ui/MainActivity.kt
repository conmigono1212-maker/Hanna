package com.cyberassistant.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cyberassistant.core.*
import com.cyberassistant.security.SecurityEngine
import com.cyberassistant.voice.VoiceEngine

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  val voice=VoiceEngine(this)
  setContent{
   var status by remember{mutableStateOf("Listo para ayudarte.")}
   var findings by remember{mutableStateOf(emptyList<Finding>())}
   MaterialTheme{
    Scaffold(topBar={TopAppBar(title={Text("CyberAssistant")})}){p->
     Column(Modifier.padding(p).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
      Text("Asistente personal cibernético",style=MaterialTheme.typography.titleLarge)
      Text(status)
      Button(onClick={
       findings=SecurityEngine(this@MainActivity).scan()
       status="Escaneo completado: ${findings.size} hallazgos."
       voice.speak(status)
      }){Text("Escanear seguridad")}
      Button(onClick={voice.speak("Hola. Soy tu asistente personal cibernético.")}){Text("Probar voz")}
      findings.take(5).forEach{f->
       Text("${f.severity}: ${f.title}\n${f.evidence}")
      }
     }
    }
   }
  }
 }
}
