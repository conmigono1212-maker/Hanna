# Hanna — CyberAssistant Android

Aplicación Android local-first de asistencia y seguridad.

## Compilación

El proyecto usa Android Gradle Plugin 8.13.0, Kotlin 2.2.20 y Java 17.

El icono de la aplicación es el emblema Hanna integrado en `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`.
